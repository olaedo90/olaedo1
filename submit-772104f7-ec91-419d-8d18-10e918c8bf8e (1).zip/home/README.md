# (Prosper Loan Data Exploration)

## by (Chizoba Onuselogu)


## Dataset

The 113,937 loans in this data collection have an average of 81 characteristics, such as loan amount, borrower rate (or interest rate), current loan status, borrower income, and many more.

The dataset is accessible [here](https://s3.amazonaws.com/udacity-hosted-downloads/ud651/prosperLoanData.csv), and feature documentation is [here](https://docs.google.com/spreadsheets/d/1gDyi L4UvIrLTEC6Wri5nbaMmkGmLQBk-Yx3z

## Summary of Findings

During my research, I discovered a significant correlation between the Prosper rating and the loan size as well as the borrower's income. Others include the loan's length and loan amount, as well as the loan's quarter of borrowing. Ratings are higher for those with higher incomes. Compared to the second half of the year, the average loan amount borrowed in the first and last quarters was higher. When I looked at the correlation between the loan amount and the quarter for each salary level, it became clear that people who make over 50,000 tended to borrow more in the first and last quarters. Additionally, persons who own a home have a higher Proper Rating than those who do not. I confirmed the connection between the loan balance and the monthly payment.
As the loan amount increases, so do the monthly payments, according to the scatter plot, which was divided into three main sections.
It was demonstrated that the monthly payment decreases with loan amount and decreases with loan length using color encoding to indicate loan length in the scatter plot.

I confirmed the association between loan length and the quarter in addition to the primary determinants of interest.
All loans from the last quarter of 2005 through the end of 2010 were due in full after 36 months. But from 2012 to 2014, there was a considerable rise in loans with a 60-month term.

## Key Insights for Presentation

I leave out the majority of the intermediate derivations in the presentation and only concentrate on the key elements related to the monthly payment and the loan amount. I first introduce the variable for the monthly payment, then I introduce the pattern in the distribution of the loan amount, and last I plot the scatterplot. I introduced the loan's term (the "loan length") and produced the scatter plot, color-coding the loan duration.

The Quarter and Income Range categories are then introduced. I first created boxplots for the loan amount and Quarter as well as the loan amount and Income Range. I then created boxplots showing the loan amount and quarter by the range of income.